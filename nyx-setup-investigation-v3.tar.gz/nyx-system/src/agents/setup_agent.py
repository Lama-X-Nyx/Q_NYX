"""
Setup Agent

Detects and validates SMC patterns on setup timeframe.
"""

import pandas as pd
from typing import Dict
from src.agents.contracts import AgentResult
from src.core.smc import SMCDetector


class SetupAgent:
    """
    Setup Agent - SMC Pattern Detection
    
    Timeframe: 15M
    Role: Detect SMC patterns (OB, FVG) and validate alignment
    
    Answers: "Is there a valid SMC setup?"
    """
    
    def __init__(self, config: Dict):
        """
        Initialize Setup Agent
        
        Args:
            config: Configuration dict
        """
        self.config = config
        self.name = 'setup'
        
        # Extract timeframe
        mtf_config = config.get('mtf', {})
        timeframes = mtf_config.get('timeframes', {})
        self.timeframe = timeframes.get('setup', '15m')
        
        # Initialize SMC Detector with explicit scalar parameters
        smc_config = config.get('smc_detector', {})
        self.smc = SMCDetector(
            ob_range_threshold=smc_config.get('ob_range_threshold', 0.015),
            fvg_min_gap=smc_config.get('fvg_min_gap', 0.005),
            liquidity_lookback=smc_config.get('liquidity_lookback', 20)
        )
        
        # Threshold
        mtf_conditions = config.get('strategy', {}).get('mtf_conditions', {})
        self.alignment_min = mtf_conditions.get('alignment_15m_min', 0.60)
    
    def analyze(self, df: pd.DataFrame, context_state: str = None) -> AgentResult:
        """
        Analyze SMC patterns and alignment
        
        Args:
            df: DataFrame for setup timeframe (15M)
            context_state: Context bias from Context Agent
        
        Returns:
            AgentResult with setup decision
        """
        
        # Get minimum bars from config
        readiness_config = self.config.get('fractal_readiness', {})
        min_bars = readiness_config.get('setup_min_bars', 50)
        
        # Readiness check - CRITICAL: Check this FIRST
        if len(df) < min_bars:
            return AgentResult(
                agent=self.name,
                state='not_ready',
                score=0.0,
                passed=False,
                ready=False,
                blocked_by_readiness=True,
                reason=f'Insufficient data ({len(df)} bars, need {min_bars})',
                metadata={'timeframe': self.timeframe, 'bars': len(df), 'min_bars': min_bars}
            )
        
        # Agent is READY - now do SMC logic
        
        # Detect SMC patterns
        try:
            patterns = self.smc.detect_all(df)
        except Exception as e:
            # Detector failed - return explicit error state
            return AgentResult(
                agent=self.name,
                state='detector_error',
                score=0.0,
                passed=False,
                ready=True,  # Data is ready, but detector failed
                blocked_by_readiness=False,
                reason=f'SMCDetector error: {type(e).__name__}: {str(e)}',
                metadata={
                    'timeframe': self.timeframe,
                    'detector_error': True,
                    'exception_type': type(e).__name__,
                    'exception_message': str(e),
                    'bars': len(df),
                    'min_bars': min_bars
                }
            )
        
        # Check pattern existence
        has_bullish = patterns.get('bullish_ob', False) or patterns.get('bullish_fvg', False)
        has_bearish = patterns.get('bearish_ob', False) or patterns.get('bearish_fvg', False)
        
        # No context provided - neutral
        if not context_state:
            if has_bullish or has_bearish:
                state = 'pattern_found'
                score = 0.5
                passed = False
                reason = 'Pattern found but no Context for alignment'
            else:
                state = 'no_pattern'
                score = 0.0
                passed = False
                reason = 'No SMC patterns detected'
        
        # Context provided - check alignment
        elif context_state == 'bullish':
            if has_bullish and not has_bearish:
                state = 'valid_setup'
                alignment = 0.75
                score = alignment
                passed = alignment >= self.alignment_min
                reason = f'Bullish pattern aligned with Context (alignment={alignment:.2f})'
            elif has_bullish and has_bearish:
                state = 'mixed_signals'
                alignment = 0.55
                score = alignment
                passed = alignment >= self.alignment_min
                reason = f'Mixed patterns (alignment={alignment:.2f})'
            else:
                state = 'misaligned'
                alignment = 0.30
                score = alignment
                passed = False
                reason = f'No bullish patterns for bullish Context (alignment={alignment:.2f})'
        
        elif context_state == 'bearish':
            if has_bearish and not has_bullish:
                state = 'valid_setup'
                alignment = 0.75
                score = alignment
                passed = alignment >= self.alignment_min
                reason = f'Bearish pattern aligned with Context (alignment={alignment:.2f})'
            elif has_bearish and has_bullish:
                state = 'mixed_signals'
                alignment = 0.55
                score = alignment
                passed = alignment >= self.alignment_min
                reason = f'Mixed patterns (alignment={alignment:.2f})'
            else:
                state = 'misaligned'
                alignment = 0.30
                score = alignment
                passed = False
                reason = f'No bearish patterns for bearish Context (alignment={alignment:.2f})'
        
        else:  # neutral
            state = 'no_bias'
            score = 0.40
            passed = False
            reason = 'Neutral Context - no directional setup required'
            alignment = 0.40
        
        # Determine pattern type
        pattern_type = None
        if patterns.get('bullish_ob'):
            pattern_type = 'bullish_ob'
        elif patterns.get('bullish_fvg'):
            pattern_type = 'bullish_fvg'
        elif patterns.get('bearish_ob'):
            pattern_type = 'bearish_ob'
        elif patterns.get('bearish_fvg'):
            pattern_type = 'bearish_fvg'
        
        return AgentResult(
            agent=self.name,
            state=state,
            score=score,
            passed=passed,
            ready=True,  # Agent is READY (has enough data)
            blocked_by_readiness=False,  # Not blocked by readiness (logic block if passed=False)
            reason=reason,
            metadata={
                'timeframe': self.timeframe,
                'patterns': patterns,
                'pattern_type': pattern_type,
                'alignment': alignment if 'alignment' in locals() else 0.0,
                'context_state': context_state,
                'bars': len(df),
                'min_bars': min_bars
            }
        )


if __name__ == "__main__":
    import sys
    sys.path.insert(0, '.')
    import numpy as np
    
    print("Setup Agent Test")
    
    # Create sample data
    dates = pd.date_range('2023-01-01', periods=200, freq='15T')
    prices = np.linspace(40000, 41000, 200)
    
    df = pd.DataFrame({
        'open': prices,
        'high': prices * 1.005,
        'low': prices * 0.995,
        'close': prices,
        'volume': np.random.rand(200) * 1000
    }, index=dates)
    
    # Test
    config = {
        'mtf': {'timeframes': {'setup': '15m'}},
        'strategy': {'mtf_conditions': {'alignment_15m_min': 0.60}}
    }
    
    agent = SetupAgent(config)
    result = agent.analyze(df, context_state='bullish')
    
    print(f"\n✅ Result:")
    print(f"  State: {result.state}")
    print(f"  Score: {result.score:.2f}")
    print(f"  Passed: {result.passed}")
    print(f"  Reason: {result.reason}")
